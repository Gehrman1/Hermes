fn main() {
    let config_max = Some(3u8);
    if let Some(lot) = config_max {
        println!("The maximum is configured to be {}", lot);
    }

}